import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-audit-result',
  templateUrl: './audit-result.html',
  styleUrls: ['./audit-result.css'],
  standalone: false
})
export class AuditResultComponent implements OnInit {

  url = '';
  result: any = null;
  desktopSelected = true;
  isSubmitting = false;
  selectedGroupIndex = 0;

  registerModel: any = {
    name: '',
    email: '',
    password: '',
    roleId: 2
  };

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    const navigation = this.router.getCurrentNavigation();
    const state = navigation?.extras?.state as any;

    if (state?.result) {
      this.result = state.result;
      this.url = state.url ?? '';
      this.selectedGroupIndex = 0;
      return;
    }

    const cached = sessionStorage.getItem('auditResult');
    const cachedUrl = sessionStorage.getItem('auditUrl');

    if (cached) {
      try {
        this.result = JSON.parse(cached);
        this.url = cachedUrl ?? '';
        this.selectedGroupIndex = 0;
      } catch (e) {
        this.router.navigate(['/']);
      }
    } else {
      this.router.navigate(['/']);
    }
  }

  // ── Safe accessors ──

  get groups(): any[] {
    return this.result?.analysis?.groups ?? [];
  }

  get stats(): any {
    return this.result?.analysis?.stats ?? {};
  }

  get selectedGroup(): any {
    return this.groups[this.selectedGroupIndex] ?? null;
  }

  // The raw pageType from the scan e.g. "Product", "Homepage"
  get pageType(): string {
    return this.result?.scanResult?.pageType ?? 'Page';
  }

  // Maps a group type to a human-readable label.
  // "PageRelated" becomes the actual page type from the scan result.
  getGroupLabel(type: string): string {
    if (!type) return '';
    if (type.toLowerCase() === 'pagerelated') {
      return `${this.pageType} Page`;
    }
    return type;
  }

  // ── Group selection ──

  selectGroup(index: number): void {
    if (this.selectedGroupIndex === index) {
      this.scrollToDetailPanel();
      return;
    }
    this.selectedGroupIndex = index;
    setTimeout(() => this.scrollToDetailPanel(), 60);
  }

  private scrollToDetailPanel(): void {
    const el = document.querySelector('.issue-detail-panel');
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  // ── Severity helpers ──

  getSeverityClass(severity: string): string {
    switch ((severity ?? '').toLowerCase()) {
      case 'critical': return 'sev-critical';
      case 'warning':  return 'sev-warning';
      case 'info':     return 'sev-info';
      default:         return 'sev-info';
    }
  }

  getGroupSeverityClass(group: any): string {
    const items: any[] = group.items ?? [];
    const hasCritical = items.some(i => i.severity?.toLowerCase() === 'critical');
    const hasWarning  = items.some(i => i.severity?.toLowerCase() === 'warning');
    if (hasCritical) return 'issue-status critical';
    if (hasWarning)  return 'issue-status warning';
    return 'issue-status info';
  }

  // ── Auth ──

  selectDesktop(): void { this.desktopSelected = true; }
  selectMobile(): void  { this.desktopSelected = false; }

  register(): void {
    if (this.isSubmitting) return;
    this.isSubmitting = true;

    this.authService.register(this.registerModel).subscribe({
      next: () => {
        const loginModel = {
          email: this.registerModel.email,
          password: this.registerModel.password
        };
        this.authService.login(loginModel).subscribe({
          next: (res: any) => {
            localStorage.setItem('token', res.token);
            localStorage.setItem('user', JSON.stringify(res.user));
            this.isSubmitting = false;
            this.router.navigate(['/user-dashboard']);
          },
          error: () => {
            this.isSubmitting = false;
            alert('Registration successful. Please login.');
          }
        });
      },
      error: (err) => {
        this.isSubmitting = false;
        alert(err.error || 'Registration failed');
      }
    });
  }
}